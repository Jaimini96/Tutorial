package com.flp.ems.util;

public class Validate {

}
