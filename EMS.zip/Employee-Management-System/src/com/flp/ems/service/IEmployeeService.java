package com.flp.ems.service;

import java.util.HashMap;

public interface IEmployeeService {

	public void addEmployee(HashMap newEmp);
		
	
	public void modifyEmployee(HashMap newEmp);
		

	public void removeEmployee(int e);
		
	

	public void searchEmployee();
		
	

	public void getAllEmployee();
		
	
}

